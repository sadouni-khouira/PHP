Exercice n°2 PHP : Inverser une chaîne de caractères

Créez une fonction qui prend en paramètre une chaine de caractères et qui retourne cette même chaine de caractères mais exactement inversée. Vous afficherez le résultat à l'aide d'un echo pour contrôler. 

Exemple :
reverse_string("abcdef GHI") ;

doit afficher "IHG fedcba" ;

Indications:
- Vous pouvez parcourir la première chaine de caractères et concaténer les caractères lus "à gauche" de la nouvelle chaine de caractères
- Ou alors vous pouvez parcourir la première chaine "à l'envers" (en partant de la fin) et construire la nouvelle chaine en concaténant normalement les caractères lus.